#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <pthread.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#define lobby "127.0.0.1"
#define port 3205

void * connectionWithServer(void *sockId)
{                                                         // Yaratılan client threadleri buraya giriyor.Serverdan      
 int clientSocket = *((int *) sockId);                    //    gelen cevaplar client'in ekranına burda yazılıyor.    

	while(1){

		char data[1024];
		int read = recv(clientSocket,data,1024,0);       //  Server'den gelen mesaj okundu.
		data[read] = '\0';
		printf("%s\n",data);

	}
   
}

int main(){

     
	int clientSocket = socket(PF_INET, SOCK_STREAM, 0);  // Clientin serverla haberleşmesi için  soket oluşturduk.
	struct sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(port);                   // 3205'e bağlandık.
    serverAddr.sin_addr.s_addr = inet_addr(lobby); 
    if (connect(clientSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0)
    {
        puts("Connection error");                        // Bağlanma hatalarını kontrol eden kod.
        return 1;
    }   
	
	printf("Welcome to DEUCHAT Please enter a nickname :\n");
    pthread_t thread;
	pthread_create(&thread, NULL, connectionWithServer, (void *) &clientSocket ); // Client için thread oluşuyor.
    while(1)
    {       
            char input[1024];                           //  Client'in isteği okunuyor.     
            scanf("%s",input);
            send(clientSocket,input,1024,0);            //  Server'a yollanıyor.
            if(strcmp(input,"-create")==0)              //  İsteklerin tipi kontrol ediliyor.
            {   	                                    //  İsteklere göre client'ten yeni inputlar alınıyor.
			    scanf("%s",input);                      //     (oda ismi,parola gibi)   
			    send(clientSocket,input,1024,0);
            }
            else if(strcmp(input,"-pcreate")==0)
            {
                scanf("%s",input);
			    send(clientSocket,input,1024,0);
            }
            else if(strcmp(input,"-quit")==0)
            {
                scanf("%s",input);
			    send(clientSocket,input,1024,0);
            }
            else if(strcmp(input,"-exit")==0)
            {
                  system("PAUSE");
                  return EXIT_SUCCESS;
            }
            else if(strcmp(input,"-enter")==0)
            {
                scanf("%s",input);
			    send(clientSocket,input,1024,0);           
            }             
    }
}
