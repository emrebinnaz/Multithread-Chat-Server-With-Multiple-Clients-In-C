#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <pthread.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <stdbool.h>

#define roomCount 20                // Oda sayısı.
#define roomCapacity 4              // Oda kapasitesi.

/*                                  AÇIKLAMA
            Programda oda sayısı 20 ve odaların kapasiteleri 4 olarak ayarlanmıştır.
        Kod istenen herşeyi yapabiliyor.Sadece client odadakilerle konusurken yazdığı
        mesajında birden çok kelime yazarsa bu kelimeleri cümlenin içinde bir satır gi-
        bi değil de alt alta yazıyor.Ama doğru bir şekilde konusabiliyorlar.Ayrıca kul-
        lanıcıdan username istenirken bir kelimeden fazla bir input girerse sadece ilk
        kelimeyi username olarak alıyor -pcreate ile oluşturulan odaların ismi ve o odadaki
        username'leri oda gizli oldgundan yazdırmıyorum.Ama -enter komutu ile gizli odaya
        ödevde istenen şekilde ulaşılabilinir..
                    
*/
struct _client{

	int index;
	int sockID;                    // Clientlerin herbirine farklı mesajlar yollamak için herbirinin socket id'si var.  
	struct sockaddr_in clientAddr; // Clientlerin adresleri. 
	int len;

};

typedef struct _client Client; 
struct _Room {
    char roomName [100]; 	    // Odaların ismi,kapasitesi,numarası,parolası ve soketleri var.
    int roomCap;                    // Bu soketlerin konulmasının amacı : Sadece o odada olan soketlere mesaj
    char password[100];             //  yollayabilmek.
    int num;
    int sockets[roomCapacity];
    char usernames[roomCapacity][100]; // odadaki clientlerin usernameleri.
};
typedef struct _Room Room;

Room rooms [roomCount];             // Oda arrayi.
Client Clients[1024];               // 1024 tane client gelebilir server'a. 

pthread_t thread[1024];             // Client thread'i.

int roomNum =0;                     // Oda sayısını tutmak için yaratıldı.
int privateRoomCount=0;             // Özel odaların sayısını tutuyor.
int clientCount = 0;                // Sisteme giren client sayısını tutuyor.

void * connectionWithClient(void * ClientDetail)
{
    Client* clientDetail = (Client*) ClientDetail; // Client'ın özelliklerini kullanabilmek için client nesnesini getirdik.   
	int index = clientDetail -> index;
	int clientSocket = clientDetail -> sockID;     // Hangi soket ile haberleşeceksek onun socketID'sini aldık.



    int firstLogin=0;                              
    bool isInRoom=false;                           // Client'ın odada olup olmadıgını kontrol ediyor.(-list,-create vb 
    bool isExited=false;                           //   komutları için gerekli)
    int enteredRoom=-1;
    char username[100];
    for(;;)
    {
        char data[1024];                           // Client'tan gelen data.
        char sendData[1024];                       // Client'a yollanan data.
		int read = recv(clientSocket,data,1024,0); // Usernameyi aldı.
		data[read] = '\0';     
        if(firstLogin==0)
        {
            strcpy(sendData,"SERVER MESSAGE>>Hi ");
            strcat(sendData,data);
            send(clientSocket,sendData,1024,0);
            send(clientSocket,"SERVER MESSAGE>>You are in lobby right now.Press enter a command :",1024,0);	
            firstLogin++;
            strcpy(username,data);
         
        }
        else
        {
             if(strcmp(data,"-whoami")==0 && isExited==false)
                {   
                    strcpy(data,username);                  
                    strcpy(sendData,"SERVER MESSAGE>> Your username is : ");
                    strcat(sendData,data);  
                    send(clientSocket,sendData,1024,0);     // Soket sayesinde işlenmiş stringi yolluyor.
                    
                }
              else if(strcmp(data,"-list")==0 && isInRoom==false && isExited==false)
                {
                    if((roomNum==0) || (roomNum==privateRoomCount)) // Sistemdeki odaların sayısı == özel oda sayısı ise
                    {                                               // Ya da hiç oda yoksa...   
                        strcpy(data,"SERVER MESSAGE>> There is no room at lobby in the DEUCHAT.");
                        strcat(sendData,data);
                        send(clientSocket,sendData,1024,0); 
                    }
                    else          
                    {
                        for(int i =0;i<roomCount;i++)
                        {
                                // odaların isimleri ve içindeki clientlerin usernamelerini gösteren kod.
                                 strcat(sendData,"Room ");
                                 strcat(sendData,rooms[i].roomName);
                                 strcat(sendData,": ");
                                 for(int j=0;j<roomCapacity;j++)
                                 {
                                    strcat(sendData,rooms[i].usernames[j]);
                                    if(j!=roomCapacity-1)
                                    strcat(sendData,",");
                                    else{
                                      strcat(sendData,"\n");              
                                    }
                                 }
                                 
                              
                        }
                          send(clientSocket,sendData,1024,0); 
                    }
                }
                 
               else if((strcmp(data,"-create")==0 && isInRoom==false && isExited==false ) ||
                        (strcmp(data,"-pcreate")==0 && isInRoom==false && isExited==false))
               {
                   bool isPrivate=false;
                   if(data[1]=='p')
                   {
                       isPrivate=true;
                   }
                   int read = recv(clientSocket,data,1024,0);
		           data[read] = '\0';                         // room name yi aldı.
                   bool isCreatedBefore=false;               // Odanın önceden yaratılıp yaratılmadıgını kontrol ediyor.
                    
                    for(int i=0;i<roomCount;i++)
                    {
                        if(strcmp(data,rooms[i].roomName)==0)
                        {
                            strcpy(sendData,">>SERVER MESSAGE : There is a room has same name.Please enter again to -create command with different room name.");
                            send(clientSocket,sendData,1024,0);
                            isCreatedBefore=true;
                            break;
                        }
                    }
                    if(isCreatedBefore!=true)                  // Önceden yaratılmadıysa yaratıyor ve odaya isim,kapasite        
                    {                                          //   parola veriliyor.
                        for(int i=0;i<roomCount;i++)
                        {
                            if(strlen(rooms[i].roomName)==0)  // Oda arrayinde boşluk varsa...
                            {   strcpy(rooms[i].roomName,data);                               
                                if(isPrivate==true)
                                {
                                    strcpy(sendData,">>SERVER MESSAGE Please enter a password for private room:");
                                    send(clientSocket,sendData,1024,0);
                                    read = recv(clientSocket,data,1024,0); // Parolayı aldı.
		                            data[read] = '\0';
                                    strcpy(rooms[i].password,data);
                                    privateRoomCount++;
                                } 
                                rooms[i].roomCap=roomCapacity-1;
                                enteredRoom=i;                          //  Client'ın girdiği odanın indexini 
                                rooms[i].num=roomNum;                   //    doğru bir şekilde mesajlaşabilmesi için 
                                isInRoom=true;                          //    tutuyorum.
                                rooms[i].sockets[0]=clientSocket;       //  Odadaki ilk soket yerine yerleşti.
                                roomNum++;                              //  Bu sokete id'si bu odanın içindeki 1 array'de olduğu için mesaj gelebilecek. 
                                strcpy(rooms[i].usernames[0],username);
                                strcpy(sendData,">>SERVER MESSAGE: Room was created.You are in room right now.");
                                send(clientSocket,sendData,1024,0);
                                break;
                            }

                        }
                        if(enteredRoom==-1)                             // 20 oda da oluştuysa.
                        {
                            strcpy(sendData,">>SERVER MESSAGE: All rooms are full.Please wait until the rooms are deleted.");
                            send(clientSocket,sendData,1024,0);
                       
                        }
                        
                    }        
               }
                else if(strcmp(data,"-enter")==0 && isInRoom==false && isExited==false)
                 {
                       
                    int read = recv(clientSocket,data,1024,0);
		            data[read] = '\0';                               // Room name yi aldı.
                    for(int i=0;i<roomCount;i++)
                    {                        
                        if(strcmp(data,rooms[i].roomName)==0)           // Doğru oda ismini girdiyse..
                        {
                            if(rooms[i].roomCap==0)                     // Odada 4 kişi varsa...
                            {
                                strcpy(sendData,"SERVER MESSAGE>>Room is full.Try anothers.");
                                send(clientSocket,sendData,1024,0);
                                break;
                            }
                            else
                            {   
                                if(strlen(rooms[i].password)>0)         // Gizli bir odaya girmeye çalışıyorsa...
                                {
                                    strcpy(sendData,"SERVER MESSAGE>>Please enter password:");
                                    send(clientSocket,sendData,1024,0);                       
                                    read = recv(clientSocket,data,1024,0); // Parolayı aldı.
		                            data[read] = '\0';
                                    if(strcmp(data,rooms[i].password)!=0)
                                    {   
                                        strcpy(sendData,"SERVER MESSAGE>>Password is not valid !Try again.\n");
                                        send(clientSocket,sendData,1024,0);
                                        break;   
                                    }
                                }
                                strcat(sendData,"SERVER MESSAGE>>You enter the room.");
                                send(clientSocket,sendData,1024,0);
                                enteredRoom=i;                           // Hangi odaya girdiği belli olsun diye yine 
                                isInRoom=true;                           //   değişkende tuttum.
                                rooms[i].roomCap--;
                                for(int j=0;j<roomCapacity;j++)
                                {
                                    if(rooms[i].sockets[j]<=0)           // Socket arrayinde elemanlar 0 değerindeler.
                                    {   strcpy(rooms[i].usernames[j],username); // Odaya username atılıyor.
                                                                         // Bu if koşulunda 0'a eşit olma ve 0'dan kü-
                                        rooms[i].sockets[j]=clientSocket;//  çük olma koşuluna bakılıyor.Çünkü ben oda-       
                                        break;                           //  dan çıkan soketlerin id lerini -10 yaptım.
                                    }                                    // Bunu yapma nedenim mesajlaşırken soket id'si
                                }                                        //  pozitif olanlara mesajların gitmesini iste-  
                                break;                                   //  memden kaynaklandı.Ayrıca odaya yeni giren 
                                                                         //  soketin id'si diğer soketlerin id'lerinin    
                            }                                            //  yerine geçemiyor.Çünkü id'ler pozitif.   
                            
                            

                        }
                        
                    }
                    
                    if((isInRoom==false && roomNum==0)|| (privateRoomCount==roomNum && isInRoom==false))
                    {
                        strcpy(sendData,"SERVER MESSAGE>>The searched room was not founded.");
                        send(clientSocket,sendData,1024,0);
                    }    
                      
                    

                }
                

                else if((strcmp(data,"-exit")==0 && isExited==false))
                {   
                    if(isInRoom==true)  // Eğer odadayken -exit'e basılırsa o odadan cıkarken bazı işlemler yapılıyor.
                    {
                        rooms[enteredRoom].roomCap++; // Oda kapasitesi arttırıldı.
                        for(int j=0;j<roomCapacity;j++)
                        {
                            if(rooms[enteredRoom].sockets[j]==clientSocket)
                            {
                                rooms[enteredRoom].sockets[j]=-10; // Yukarıda bahsettiğim gibi bu soketin başkalarıyla
                                                                    //  konuşmasını engellemek için değerini -10 yaptım.
                                char temp [100];
                                strcpy(temp,rooms[enteredRoom].usernames[j]);
                                temp[0]='\0';
                                strcpy(rooms[enteredRoom].usernames[j],temp);
                                break;                              //odadan cıkan clientin username'i siliniyor.
                                      
                                                             

                            }
                        }
                        if(rooms[enteredRoom].roomCap==4)          //  Odada kimse kalmadıysa...
                        {
                            rooms[enteredRoom].roomName[0]='\0';   //  Oda kapansın.
                             if(strlen(rooms[enteredRoom].password)>0)
                            {
                                rooms[enteredRoom].password[0]='\0';
                                privateRoomCount--;
                            }
                            roomNum--;     
                        }
                        enteredRoom=-1;
                        isInRoom=false;
                       
                    }
                    strcpy(sendData,"Goodbye.");
                    send(clientSocket,sendData,1024,0);
                    isExited=true;
                    
                        
                }
                else if(strcmp(data,"-quit")==0 && isInRoom==true && isExited==false)
                {
                      int read = recv(clientSocket,data,1024,0);
		              data[read] = '\0';                           // Room name yi aldı.   
                       for(int i=0;i<roomCount;i++)                // Yukarıda yapılan şeylerin aynıları yapılıyor.
                       {
                           if(strcmp(data,rooms[i].roomName)==0 && enteredRoom==i) 
                           {                                        // Girdiği odanın no.su i'ye eşitse çıksın
                                strcpy(sendData,">>SERVER MESSAGE:You left the room.");
                                send(clientSocket,sendData,1024,0);
                                isInRoom=false;
                                rooms[enteredRoom].roomCap++;
                                for(int j=0;j<roomCapacity;j++)
                                {
                                  if(rooms[i].sockets[j]==clientSocket)
                                  {
                                    rooms[i].sockets[j]=-10;    
                                    char temp [100];
                                    strcpy(temp,rooms[enteredRoom].usernames[j]);
                                    temp[0]='\0';
                                    strcpy(rooms[enteredRoom].usernames[j],temp);
                                    break;                              //odadan cıkan clientin username'i siliniyor.  
                                  }
                                }
                                if(rooms[enteredRoom].roomCap==4)
                                {
                                    rooms[enteredRoom].roomName[0]='\0';
                                    rooms[enteredRoom].num=-1;
                                  if(strlen(rooms[enteredRoom].password)>0)
                                  {
                                    rooms[enteredRoom].password[0]='\0';
                                    privateRoomCount--;
                                  }
                                  roomNum--;     
                                }
                                enteredRoom=-1;
                                break;
                           }
                           if(i==roomCount-1)
                           {
                                strcpy(sendData,">>SERVER MESSAGE:You entered wrong room name.Please try again.");
                                send(clientSocket,sendData,1024,0);
                                break;
                               
                           }
                       } 
                }
                else if(isInRoom==false && isExited==false)   // Lobideyse ve komutlardan farklı bir şey girerse...
                {
                     strcpy(sendData,"SERVER MESSAGE>>It is invalid command.Please try another commands.");
                     send(clientSocket,sendData,1024,0);                 
                }
                else if(isInRoom==true && isExited==false)   // Odada olup komut girmesse(sohbet)
                {
                  for(int i=0;i<roomCount;i++)
                    {
                        if(enteredRoom==i)       //  Girdiği odayı buluyor.(num yerine i ? )
                        {   
                            strcat(sendData,"{");
                            strcat(sendData,username);      // Kimin yazdığını belli etmek için usernameyi ilgili
                            strcat(sendData,"}:");          //  clientlara yolluyoruz.
                            strcat(sendData,data);
                            for(int j=0;j<roomCapacity;j++)
                            {
                                if(rooms[i].sockets[j]!=clientSocket && rooms[i].sockets[j]>0)
                                send(rooms[i].sockets[j],sendData,1024,0);     
                                /* Yukarıdaki if koşulunun anlamı şu:
                                        Eğer soket arrayindeki değer kendi soketi değilse ve 
                                        soketin id'si 0 dan büyükse(silinmemiş veya oluşturulmuş ise)
                                        ilgili client'in soketine mesajı yolla.
                                */                            
                            }                                                   
                        }
                    } 

                }
       
        }
       

    }
    	return NULL;



}


int main(){

	int serverSocket = socket(PF_INET, SOCK_STREAM, 0); // Server socketi oluşturuluyor.

	struct sockaddr_in serverAddr;          

	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(3205);                 // Port bağlantısı gerçekleştirildi.
	serverAddr.sin_addr.s_addr = htons(INADDR_ANY);


	if(bind(serverSocket,(struct sockaddr *) &serverAddr , sizeof(serverAddr)) == -1) return 0;

	if(listen(serverSocket,1024) == -1) return 0;

	printf("Lobby was opened. ...........\n");      
    while(1){

		Clients[clientCount].sockID = accept(serverSocket, (struct sockaddr*) &Clients[clientCount].clientAddr, &Clients[clientCount].len);
		// Client soketi kabul edildi.SocketID tanımlandı.
		Clients[clientCount].index = clientCount;

		pthread_create(&thread[clientCount], NULL, connectionWithClient, (void *) &Clients[clientCount]);
        // Thread oluşturuldu.
		clientCount ++;
 
	}

	for(int i = 0 ; i < clientCount ; i ++)
		pthread_join(thread[i],NULL);
        //  Threadler join oldu.
}
